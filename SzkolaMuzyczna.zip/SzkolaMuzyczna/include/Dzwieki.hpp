//
// Created by s434804 on 6/13/18.
//

#ifndef SZKOLAMUZYCZNA_DZWIEKI_HPP
#define SZKOLAMUZYCZNA_DZWIEKI_HPP
#include <iostream>

using namespace std;

class Dzwiek{
    int nuta,nuta2;
    int zlicz = 0;
public:
    void interwaly();
    void tekst();
};
#endif //SZKOLAMUZYCZNA_DZWIEKI_HPP
