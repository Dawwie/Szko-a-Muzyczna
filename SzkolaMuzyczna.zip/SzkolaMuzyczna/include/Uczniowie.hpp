//
// Created by s434804 on 6/12/18.
//

#ifndef SZKOLAMUZYCZNA_UCZNIOWIE_HPP
#define SZKOLAMUZYCZNA_UCZNIOWIE_HPP
#include <iostream>
#include <fstream>
using namespace std;
class Uczen{
    string wiek,rok;
protected:
    string imie,nazwisko;
    fstream plik;
public:
    Uczen(string="brak", string="brak", string="brak", string="brak");
    void wypUcznia();
    void dodUcznia();
};

#endif //SZKOLAMUZYCZNA_UCZNIOWIE_HPP
