//
// Created by s434804 on 6/13/18.
//

#ifndef SZKOLAMUZYCZNA_LISTA_HPP
#define SZKOLAMUZYCZNA_LISTA_HPP
#include <iostream>
#include <fstream>
#include "../include/Uczniowie.hpp"

using namespace std;

class Lista: public Uczen{
protected:
    int nr_linii=1;
    string linia;
public:
    void WypiszListeUczniow();
    void WypiszListeUtworow();
};

#endif //SZKOLAMUZYCZNA_LISTA_HPP
