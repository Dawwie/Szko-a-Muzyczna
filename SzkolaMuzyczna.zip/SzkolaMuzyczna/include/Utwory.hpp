//
// Created by s434804 on 6/13/18.
//

#ifndef SZKOLAMUZYCZNA_UTWORY_HPP
#define SZKOLAMUZYCZNA_UTWORY_HPP

#include <iostream>
#include <fstream>
#include "../include/Uczniowie.hpp"
using namespace std;
class Utwor : public Uczen{
    string imie,nazwisko,nazwa,bpm,dynamika;
public:
    Utwor(string="brak", string="brak", string="brak", string="brak", string="brak");
    void dodUtwor();
};
#endif //SZKOLAMUZYCZNA_UTWORY_HPP
