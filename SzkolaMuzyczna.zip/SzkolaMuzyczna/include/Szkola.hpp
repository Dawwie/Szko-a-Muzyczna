//
// Created by s434804 on 6/12/18.
//

#ifndef SZKOLAMUZYCZNA_SZKOLA_HPP
#define SZKOLAMUZYCZNA_SZKOLA_HPP
#include <iostream>
using namespace std;
class Szkola{
public:
   void menu();
};

#endif //SZKOLAMUZYCZNA_SZKOLA_HPP
