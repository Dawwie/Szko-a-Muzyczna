//
// Created by s434804 on 6/12/18.
//

#ifndef SZKOLAMUZYCZNA_NAUCZYCIELE_HPP
#define SZKOLAMUZYCZNA_NAUCZYCIELE_HPP
#include <iostream>
#include <fstream>
#include "../include/Lista.hpp"
using namespace std;

class Nauczyciel: public Lista {
    int nr=0;
    string imie[10],nazwisko[10],instrument[10];
public:
    void WypiszListeNaucz();
};
#endif //SZKOLAMUZYCZNA_NAUCZYCIELE_HPP
