//
// Created by s434804 on 6/12/18.
//

#ifndef SZKOLAMUZYCZNA_INSTRUMENTY_HPP
#define SZKOLAMUZYCZNA_INSTRUMENTY_HPP
#include <iostream>
#include <string>
#include "../include/Lista.hpp"
using namespace std;

class Instrument: public Lista{
public:
    void wypStrunowe();
    void wypDete();
    void wypPerkusyjne();
};



#endif //SZKOLAMUZYCZNA_INSTRUMENTY_HPP
