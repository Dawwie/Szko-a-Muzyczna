#include <iostream>
#include "../include/Uczniowie.hpp"
#include "../include/Nauczyciele.hpp"
#include "../include/Szkola.hpp"
#include "../include/Instrumenty.hpp"
#include "../include/Lista.hpp"
#include "../include/Dzwieki.hpp"
#include "../include/Utwory.hpp"
using namespace std;

int main() {
Uczen U;
Lista L;
Nauczyciel N;
Instrument I;
Dzwiek D;
Utwor Ut;
Szkola S;
char wybierz,wyjdz;
    while(true){
        S.menu();
        cout<< "-> "; cin >> wybierz;
        switch(wybierz)
        {
            case '1':
                while(true) {
                    while(wyjdz != '0') {
                        U.dodUcznia();
                        U.wypUcznia();
                        cout << "Aby kontynuować '1',aby wrócić wpisz '0'." << endl;
                        cin >> wyjdz;
                    }
                    main();
                    break;
                }
            case '2':
                while(true) {
                    while (wyjdz != '0') {
                        L.WypiszListeUczniow();
                        cout << "Aby wrócić wpisz '0'." << endl;
                        cin >> wyjdz;
                    }
                    main();
                    break;
                }
            case '3':
                    while (wyjdz != '0') {
                        N.WypiszListeNaucz();
                        cout << "Aby wrócić wpisz '0'." << endl;
                        cin >> wyjdz;
                    }
                    main();
                    break;
            case '4':
                char n;
                while(n != '0'){
                    cout << "INSTRUMENTY MUZYCZNE" << endl;
                    cout << "1 - STRUNOWE" << endl;
                    cout << "2 - DĘTĘ" << endl;
                    cout << "3 - PERKUSYJNE" << endl;
                    cout << "0 - wróć" << endl;
                    cout<< "-> "; cin >> n;
                    switch(n)
                    {
                        case '1': I.wypStrunowe();break;
                        case '2': I.wypDete();break;
                        case '3': I.wypPerkusyjne();break;
                        case '0': main();break;
                    }
                    break;
                }
            case '5':
                D.tekst();
                while(wyjdz != '0'){
                    D.interwaly();
                    cout << "Aby kontynuować '1',aby wrócić wpisz '0'." << endl;
                    cin >> wyjdz;
                }
                main();
                break;
            case '6':
                while(wyjdz != '0'){
                    Ut.dodUtwor();
                    cout << "Aby kontynuować '1',aby wrócić wpisz '0'." << endl;
                    cin >> wyjdz;
                }
                main();
                break;
            case '7':
                while(wyjdz != '0'){
                    L.WypiszListeUtworow();
                    cout << "Aby wrócić wpisz '0'." << endl;
                    cin >> wyjdz;
                }
                main();
                break;
            default:
                exit(0);
        }
    }

    return 0;
}