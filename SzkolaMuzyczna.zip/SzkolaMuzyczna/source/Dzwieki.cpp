//
// Created by s434804 on 6/13/18.
//

#include "../include/Dzwieki.hpp"
using namespace std;

void Dzwiek::interwaly() {
    cout << "Pierwszy dźwięk: "; cin >> nuta;
    cout << "Drugi dźwięk: "; cin >> nuta2;
    cout << endl;
    if (nuta2 < nuta){swap(nuta2,nuta);}
    for(int i = nuta; i<=nuta2 ;i++){zlicz++;}
    if(nuta == nuta2){cout <<  "Pryma";}
    if(nuta2 - nuta == 1){cout <<  "Sekunda";}
    if(nuta2 - nuta == 2){cout <<  "Tercja";}
    if(nuta2 - nuta == 3){cout <<  "Kwarta";}
    if(nuta2 - nuta== 4){cout <<  "Kwinta";}
    if(nuta2 - nuta== 5){cout <<  "Seksta";}
    if(nuta2 - nuta== 6){cout <<  "Septyma";}
    if(nuta2 - nuta== 7){cout << "Oktawa";}
    zlicz = 0;
    cout << endl;
    }


void Dzwiek::tekst() {
    cout << "Interwały mówią nam o ile tonów dane dźwięki są od siebie oddalone." << endl;
    cout << "Wybierz dźwięki, aby dowiedzieć się jaki to interwał." << endl;
    cout << "1 - c(do)" << endl;
    cout << "2 - d(re)" << endl;
    cout << "3 - e(mi)" << endl;
    cout << "4 - f(fa)" << endl;
    cout << "5 - g(sol)" << endl;
    cout << "6 - a(la)" << endl;
    cout << "7 - h(si)" << endl;
    cout << "8 - C(do)" << endl;
}