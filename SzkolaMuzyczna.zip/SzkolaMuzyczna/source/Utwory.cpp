//
// Created by s434804 on 6/13/18.
//
#include <iostream>
#include "../include/Utwory.hpp"
using namespace std;

void Utwor::dodUtwor(){
    cout << "Skomponuj swój własny utwór!" << endl;
    cout << "Imie: "; cin >> imie;
    cout << "Nazwisko: "; cin >> nazwisko;
    cout << "Nazwa utworu: "; cin >> nazwa;
    cout << "Szybkosc: "; cin >> bpm;
    cout << "Dynamika: "; cin >> dynamika;
    plik.open("/home/students/s434804/CLionProjects/SzkolaMuzyczna/files/utwory.txt",ios::out | ios::app);
    plik << imie << " " << nazwisko << endl << nazwa << " " << bpm << " "  << dynamika << endl;
    plik << "-----------------------" << endl;
    plik.close();
    plik.clear();
}


Utwor::Utwor(string _imie, string _nazwisko, string _nazwa , string _bpm, string _dynamika){
    _imie = imie;
    _nazwisko = nazwisko;
    _nazwa = nazwa;
    _bpm = bpm;
    _dynamika = dynamika;
}

//Utwor::~Utwor();
