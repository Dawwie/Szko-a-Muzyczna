//
// Created by s434804 on 6/11/18.
//
#include <iostream>
#include <fstream>
#include "../include/Uczniowie.hpp"
using namespace std;

void Uczen::dodUcznia(){
    cout  << "Imie: ";
    cin >> imie;
    cout << "Nazwisko: ";
    cin >> nazwisko;
    cout << "Wiek: ";
    cin >> wiek;
    cout << "Na roku: ";
    cin >> rok;
    cout << endl;
    plik.open("/home/students/s434804/CLionProjects/SzkolaMuzyczna/files/uczniowie.txt",ios::out | ios::app);
    plik << imie << " " << nazwisko << " lat " << wiek << endl << "Rok nauki: " << rok  << endl;
    plik << "-----------------------" << endl;
    plik.close();
    plik.clear();
}

void Uczen::wypUcznia() {
    cout << "Dodano ucznia" << endl;
    cout << imie << " " << nazwisko << " lat " << wiek << endl << "Rok nauki: " << rok  << endl;
}


Uczen::Uczen(string _imie, string _nazwisko, string _wiek, string _rok){
    imie = _imie;
    nazwisko = _nazwisko;
    wiek = _wiek;
    rok = _rok;
}

