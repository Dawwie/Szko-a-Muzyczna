//
// Created by s434804 on 6/11/18.
//
#include <iostream>
#include <fstream>
#include "../include/Nauczyciele.hpp"
using namespace std;

void Nauczyciel::WypiszListeNaucz(){
    plik.open("/home/students/s434804/CLionProjects/SzkolaMuzyczna/files/nauczyciele.txt",ios::in);
    if(plik.good()==false){
        cout << "Podany plik nie istnieje." << endl;
    }
    while(!plik.eof()){
        getline(plik,linia);
        switch(nr_linii){
            case 1: imie[nr] = linia; break;
            case 2: nazwisko[nr] = linia; break;
            case 3: instrument[nr] = linia; break;
        }
        if(nr_linii == 3) {nr_linii = 0 ;nr++;}

       nr_linii++;
    }
    plik.close();
    plik.clear();

    for(int i = 0; i <= 8; i++){
        cout << "Imie: " << imie[i] << endl;
        cout << "Nazwisko: " << nazwisko[i] << endl;
        cout << "Instrument: " << instrument[i] << endl;
        cout << endl;
    }
}
