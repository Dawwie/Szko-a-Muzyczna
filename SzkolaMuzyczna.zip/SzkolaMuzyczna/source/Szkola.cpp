//
// Created by s434804 on 6/12/18.
//

#include <iostream>
#include "../include/Szkola.hpp"
using namespace std;

void Szkola::menu() {
    cout << "Witaj w szkole muzycznej!" << endl;
    cout << "Wybierz opcje" << endl;
    cout << "1 - Dodaj Ucznia" << endl;
    cout << "2 - Lista  bieżących uczniów" << endl;
    cout << "3 - Lista nauczycieli uczących w szkole" << endl;
    cout << "4 - Wykaz instrumentów muzycznych" << endl;
    cout << "5 - Interwały" << endl;
    cout << "6 - Skomponuj swój utwór" << endl;
    cout << "7 - Lista stworzonych utworów" << endl;
    cout << "0 - Exit" << endl;
}
