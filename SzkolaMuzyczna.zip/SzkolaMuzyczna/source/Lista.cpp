//
// Created by s434804 on 6/13/18.
//
#include <iostream>
#include <fstream>
#include "../include/Lista.hpp"
using namespace std;

void Lista::WypiszListeUczniow() {
        plik.open("/home/students/s434804/CLionProjects/SzkolaMuzyczna/files/uczniowie.txt",ios::in);
        if(plik.good()==false){
            cout << "Podany plik nie istnieje." << endl;
        }
        while(!plik.eof()){
            getline(plik,linia);
            cout << linia << endl;
            nr_linii++;
        }
        plik.close();
        plik.clear();
    }

void Lista::WypiszListeUtworow(){
    plik.open("/home/students/s434804/CLionProjects/SzkolaMuzyczna/files/utwory.txt",ios::in);
    if(plik.good()==false){
        cout << "Podany plik nie istnieje." << endl;
    }
    while(!plik.eof()){
        getline(plik,linia);
        cout << linia << endl;
        nr_linii++;
    }
    plik.close();
    plik.clear();
}
