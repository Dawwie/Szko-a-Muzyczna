//
// Created by s434804 on 6/13/18.
//
#include <iostream>
#include <fstream>
#include "../include/Instrumenty.hpp"
using namespace std;

void Instrument::wypStrunowe() {
    plik.open("/home/students/s434804/CLionProjects/SzkolaMuzyczna/files/strunowe.txt",ios::in);
    if(plik.good()==false){
        cout << "Podany plik nie istnieje." << endl;
    }
    while(!plik.eof()){
        getline(plik,linia);
        cout << linia << endl;
        nr_linii++;
    }
    plik.close();
    plik.clear();
}

void Instrument::wypDete() {
    plik.open("/home/students/s434804/CLionProjects/SzkolaMuzyczna/files/dete.txt",ios::in);
    if(plik.good()==false){
        cout << "Podany plik nie istnieje." << endl;
    }
    while(!plik.eof()){
        getline(plik,linia);
        cout << linia << endl;
        nr_linii++;
    }
    plik.close();
    plik.clear();
}

void Instrument::wypPerkusyjne(){
    plik.open("/home/students/s434804/CLionProjects/SzkolaMuzyczna/files/perkusyjne.txt",ios::in);
    if(plik.good()==false){
        cout << "Podany plik nie istnieje." << endl;
    }
    while(!plik.eof()){
        getline(plik,linia);
        cout << linia << endl;
        nr_linii++;
    }
    plik.close();
    plik.clear();
}
